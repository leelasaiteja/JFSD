package com.jfsd.jobportal.service;

import com.jfsd.jobportal.models.Recruiter;
import java.util.List;

public interface RecruiterService {
    Recruiter saveRecruiter(Recruiter recruiter);
    Recruiter getRecruiter(String mobile);
    List<Recruiter> getRecruiters();
    String checkRecruiter(String email, String password);
}
