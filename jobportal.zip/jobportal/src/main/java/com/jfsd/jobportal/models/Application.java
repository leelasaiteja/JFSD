package com.jfsd.jobportal.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name="applications")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    @Column(name = "mobile")
    private String mobile;
    @Column(name="email")
    private String email;
    @Column(name="fname")
    private String firstName;
    @Column(name="lname")
    private String lastName;
    @Column(name="age")
    private int age;

    @ManyToOne(fetch = FetchType.LAZY) // You can use FetchType.EAGER based on your requirement
    @JoinColumn(name = "job_id", nullable = false) // Ensure this column exists in your applications table
    @JsonIgnore
    private Job job;

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }
}
