package com.jfsd.jobportal.controller;

import com.jfsd.jobportal.exception.ResourceNotFoundException;
import com.jfsd.jobportal.models.*;
import com.jfsd.jobportal.repository.ApplicationRepository;
import com.jfsd.jobportal.repository.JobRepository;
import com.jfsd.jobportal.repository.RecruiterRepository;
import com.jfsd.jobportal.service.*;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
//@RequestMapping("/api")
@CrossOrigin("http://localhost:3000")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RecruiterService recruiterService;
    @Autowired
    private JobService jobService;
    @Autowired
    private ApplicationService applicationService;
    @Autowired
    private AdminService adminService;
    @Autowired
    private RecruiterRepository recruiterRepository;
    @Autowired
    private JobRepository jobRepository;
    @Autowired
    private ApplicationRepository applicationRepository;

    //create user Rest API
    @PostMapping("/user")
    public ResponseEntity<User> saveEmployee(@Valid @RequestBody User user){
        return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
    }
    //get user Rest API
    @GetMapping("/user/{mobile}")
    public ResponseEntity<User> getUser(@PathVariable String mobile){
        return ResponseEntity.ok(userService.getUser(mobile));
    }
    @GetMapping("/users")
    public ResponseEntity<List<User>> getUsers(){
        return ResponseEntity.ok(userService.getUsers());
    }

    @PostMapping("/userlogin/{email}/{password}")
    public ResponseEntity<String> checkUser(@PathVariable String email, @PathVariable String password) {
        System.out.println("Received email: " + email + ", password: " + password);

        String user = userService.checkUser(email, password);
        if (user != null) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }





    @PostMapping("/recruiter")
    public ResponseEntity<Recruiter> saveRecruiter(@Valid @RequestBody Recruiter recruiter){
        return new ResponseEntity<>(recruiterService.saveRecruiter(recruiter), HttpStatus.CREATED);
    }
    @GetMapping("/recruiter/{mobile}")
    public ResponseEntity<Recruiter> getRecruiter(@PathVariable String mobile){
        return ResponseEntity.ok(recruiterService.getRecruiter(mobile));
    }
    @GetMapping("/recruiters")
    public ResponseEntity<List<Recruiter>> getRecruiters(){
        return ResponseEntity.ok(recruiterService.getRecruiters());
    }
    @PostMapping("/recruiterlogin/{email}/{password}")
    public ResponseEntity<?> checkRecruiter(@PathVariable String email, @PathVariable String password) {
        System.out.println("Received email: " + email + ", password: " + password);

        String user = recruiterService.checkRecruiter(email, password);
        if (user != null) {
            // Return recruiter object if credentials are valid
            Recruiter recruiter = recruiterRepository.findByEmail(email);
            if (recruiter != null) {
                return ResponseEntity.ok(recruiter); // Returns the recruiter details
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Recruiter not found");
            }
        } else {
            // Return unauthorized status with a message
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    @PostMapping("/job")
    public ResponseEntity<Job> saveJob(@RequestBody Job job) {
        // Retrieve the recruiter from the database by ID
        if (job.getRecruiter() == null || job.getRecruiter().getId() <= 0) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Invalid recruiter ID
        }

        Recruiter recruiter = recruiterRepository.findById(job.getRecruiter().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter not found"));

        // Set the recruiter to the job
        job.setRecruiter(recruiter);

        // Save the job with the recruiter
        return new ResponseEntity<>(jobService.saveJob(job), HttpStatus.CREATED);
    }


    @GetMapping("/job/{id}")
    public ResponseEntity<JobDTO> getJob(@PathVariable int id){

        Job job = jobRepository.findByid(id);;
        JobDTO jobDTO = new JobDTO(
                job.getId(),
                job.getName(),
                job.getCompany(),
                job.getSalary(),
                job.getLocation(),
                job.getDescription()
        );
        return new ResponseEntity<>(jobDTO, HttpStatus.OK);
    }
    @GetMapping("/jobs")
    public ResponseEntity<List<JobDTO>> getAllJobs() {
        List<Job> jobs = jobRepository.findAll();
        List<JobDTO> jobDTOs = jobs.stream()
                .map(job -> {
                    JobDTO dto = new JobDTO(
                            job.getId(),
                            job.getName(),
                            job.getCompany(),
                            job.getSalary(),
                            job.getLocation(),
                            job.getDescription()
                    );

                    return dto;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(jobDTOs);
    }

    @PostMapping("/application")
    public ResponseEntity<Application> saveApplication(@RequestBody Application application) {
        System.out.println("Received application: " + application);
        if(application.getJob().getId()<=0){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Job job = jobRepository.findById(application.getJob().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Job not found"));

        application.setJob(job);
        return new ResponseEntity<>(applicationService.saveApplication(application), HttpStatus.CREATED);
    }



    //    @GetMapping("/applications/{mobile}")
//    public ResponseEntity<Application> getApplication(@PathVariable String mobile){
//        return ResponseEntity.ok(applicationService.getApplication(mobile));
//    }
    @GetMapping("/applications/{recruiterId}")
    public List<Application> getApplicationsByRecruiter(@PathVariable int recruiterId) {
        return applicationService.getApplicationsByRecruiterId(recruiterId);
    }
//    @GetMapping("/applications/all")
//    public ResponseEntity<List<Application>> getApplications(){
//        return ResponseEntity.ok(applicationService.getApplications());
//    }
    @PostMapping("/createAdmin")
    public ResponseEntity<Admin> saveAdmin(@RequestBody Admin admin){
        return new ResponseEntity<>(adminService.saveAdmin(admin),HttpStatus.CREATED);
    }

    @PostMapping("/adminLogin")
    public ResponseEntity<String> checkAdmin(@RequestParam String username,@RequestParam String password, HttpSession session){

        String s = adminService.checkAdmin(username,password);

        if(s!=null) {
            session.setAttribute("adminLoggedIn", true);
            return ResponseEntity.status(HttpStatus.FOUND)
                    .header("Location", "/api/admin")  // Redirect to /admin endpoint
                    .build();
        }else
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Credintials");
    }
    @GetMapping("/admin")
    public ResponseEntity<String> admin(){
        return ResponseEntity.ok("Hello admin");
    }
    @PostMapping("/admin/logout")
    public ResponseEntity<String> logoutAdmin(HttpSession session){
        session.invalidate();

        return ResponseEntity.status(HttpStatus.FOUND)
                .header("Location", "/api/adminLogin")
                .build();
    }
    @GetMapping("/admin/users")
    public ResponseEntity<List<User>> viewUsers(HttpSession session){
        boolean adminLoggedIn = (Boolean)session.getAttribute("adminLoggedIn");
        if(adminLoggedIn){
            return ResponseEntity.ok(adminService.viewUsers());
        }else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }

    }


}
